import com.binarytree.*;
import com.link.*;

import java.util.Scanner;

public class BSTDriver {
	
	public static void main(String[] args) {
		Link root = null;
		Scanner scan = new Scanner(System.in);
		BinaryTree bt = new BinaryTree();
		char ch = 'Y';
		while(ch == 'y' || ch == 'Y') {
			System.out.println("Binary Search Tree");
			System.out.println("1. Insert into tree");
			System.out.println("2. Delete from tree");
			System.out.println("3. Inorder traversal");
			System.out.println("4. Preorder traversal");
			System.out.println("5. Postorder traversal");
			System.out.println("6. Search the tree");
			System.out.print("Please enter your choice?");
			int ans, ele;
			ans = scan.nextInt();
			switch(ans) {
				case 1 :System.out.println("Please enter number?");
						ele = scan.nextInt();
						root = bt.insert(root,ele);
						break;
				case 2: System.out.println("Please enter number to delete?");
						ele = scan.nextInt();
						root = bt.deleteNode(root,ele);
						break;
				case 3: System.out.println("INORDER TRAVERSAL:");
						bt.inorder(root);
						break;
				case 4: System.out.println("PREORDER TRAVERSAL:");
						bt.preorder(root);
						break;
				case 5: System.out.println("POSTORDER TRAVERSAL:");
						bt.postorder(root);
						break;
				case 6: System.out.println("SEARCH FOR ITEM: ");
						ele = scan.nextInt();
						search(root,ele);
						break;
				default:System.out.println("WRONG CHOICE");
			}
			System.out.println("DO YOU WISH TO CONTINUE?(YES/NO)");
			ch = scan.next().charAt(0);
		}
		scan.close();
	}
	
	public static void search(Link node , int data) {
		if (node == null){
			System.out.println("NOT FOUND!");
		}
		else if (node.getData() == data) {
			System.out.println("FOUND!" + data);
		}
		else if (data < node.getData()) {
			search(node.getLeft() , data);
		}
		else if (data > node.getData()) {
			search(node.getRight() , data);
		}
	}
}
