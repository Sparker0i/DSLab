#include<stdio.h>
int main()//Programmed by Gautham AM.EN.U4CSE15025
{
int top,cho,i;
char array[15]={'A','B','C','D','E','F','G','H','I','J'};
top=9;
x:
printf("\nSTACK OPERATIONS\n\t1.Insert\n\t2.Remove\n\t3.Check Full\n\t4.Check Empty\n\t5.Display\n\t6.Exit\nEnter your choice?");
scanf("%d",&cho);
switch(cho){
case 1:if(top==14)
       printf("\nMemory Full\n");
       else{top=top+1;
       scanf("%c ",&array[top]);}
       goto y;
case 2:if(top=-1)
        printf("\nNothing to clear!\n");
        else
        top=top-1;
        goto y;
case 3:if(top==14) printf("\nFull!\n");
       else printf("\nNot Full!\n");
       goto x;
case 4:if(top==-1) printf("\nEmpty!\n");
       else printf("\nNot Empty!\n");
       goto x;
case 5:y:
       if(top==-1)
       printf("\nEmpty\n");
       else{printf("\n");
       for(i=0;i<=top;i++)
        printf("%c\t",array[i]);
        printf("\n");}
        goto x;
case 6:break;
default:goto x;
}
return 0;
}
