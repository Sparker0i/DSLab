import java.io.*;
public class Inpost {
  public static void main(String[] args) throws Exception {
    String s;
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    MyStack st=new MyStack();
    System.out.println("Enter String :");
    s=br.readLine();
    st.printPostfix(s);
    System.out.println("");
  }
}
