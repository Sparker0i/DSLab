import java.io.*;
class MyStack
{   char stack[]=new char[30];
    private int top=-1;
    public boolean isFull()
    {
      if(top==29)
        return true;
      else
        return false; 
    }
    
    public void push(char c)
    {  
       if(isFull()==true)
       {
          System.out.println("Stack is Full");
          return;
       }
       else 
       {
         top=top+1;
         stack[top]=c; 
       }
    }
    
    public boolean isEmpty()
    {
      if(top==-1)
         return true;
      else
         return false; 
    }
    
    public void pop()
    {
      if(isEmpty()==true)
      {
         System.out.println("Stack is Empty");
         return;
      }
      else 
         top=top-1; 
    }
   
    public int pref(char c)
    { int n=0; 
      switch(c)
      { case '/' : n=4;
                   break;
        case '*' : n=3;
                   break; 
        case '+' : n=2;
                   break;
        case '-' : n=1;
                   break; 
        case '^' : n=5;
                   break;
        case '(' : n=0;
      }
      return n;     
    }
    
    public boolean isSymbol(char c)
    {
       boolean p;
       switch(c)
       { case '/' : p=true;
                    break; 
         case '*' : p=true;
                    break;
         case '+' : p=true;
                    break; 
         case '-' : p=true;
                    break;
         case '^' : p=true;
                    break; 
         default : p=false;
       }
       return p;
    }
    
   public char getTop()
   { return stack[top];
   }

   public void display()
   { int i;
     for(i=0;i<=top;i++)
       System.out.print(stack[i]+" ");
     System.out.println(""); 
   } 
   public void printPostfix(String s)
   {
      int i,j;
      char ch;
      for(i=0;i<s.length();i++)
      {  ch=s.charAt(i);
         if(isSymbol(ch)==true)
         {   //System.out.print(" #"+"\n");
            if(isEmpty()==true)
              push(ch);
            else if(pref(ch)>=pref(getTop()))
              push(ch);
            else {
              while(pref(ch)<pref(getTop())) {
                 System.out.print(getTop());
                 pop();
                 if(isEmpty()==true)
                   break;
              }
              push(ch); 
            }
         }
         
         else if(ch=='(')
            push(ch);

         else if(ch==')') {
            while(getTop()!='(') {
               System.out.print(getTop());
               pop();  
            }
            pop();
         }
        
        else {
            System.out.print(ch);
        } 
        //end for  
      }
      while(isEmpty()==false)
      {
         System.out.print(getTop());
         pop();
      }  
    //end print
   }

   public boolean isNum(char c){
      if(c>='0' && c<='9')
        return true;
      else
        return false;
   }
}
