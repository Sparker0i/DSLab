import java.io.*;
public class InpostOperation{
  public static void main(String[] args) throws Exception{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String s=br.readLine();
		Deck d=new Deck();
		int i,n,temp,a,b,ans=0;
		char c;
		for(i=0;i<s.length();i++)
		{  
			c=s.charAt(i);
       //System.out.println(c);
			if(d.isSymbol(c)==false){
          //System.out.print("Not an operand ");
            if(d.isNum(c)==true){
            //System.out.prinln("getting a digit "+c)
				n = c - '0';
				i = i + 1;
            while(d.isNum(s.charAt(i))==true){
				temp=s.charAt(i)-'0';
				n=n*10+temp;
				i=i+1;
            }
            i=i-1;
            d.push(n); 
           //number is pushed into a stack
          }
         else {
            continue; 
         }
  
       }
       else {
         ans=0;
         a=d.getTop();
         d.pop();
         b=d.getTop();
         d.pop();
         switch(c){
           case '*' : ans=a*b;
                      break;
           case '/' : ans=b/a;
                      break;
           case '+' : ans=a+b;
                      break;
           case '-' : ans=b-a;
                      break;
           case '^' : ans=1;
                      for(temp=1;temp<=b;temp++)
                        ans=ans*a;
                      break;
         }//done the required operation
         d.push(ans);
         //new number pushed to the stack 
       }
       
    }//iteration over
    System.out.println(d.getTop()+" ");
    
  }
}
