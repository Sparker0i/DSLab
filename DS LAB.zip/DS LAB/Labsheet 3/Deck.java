public class Deck {
  private static int length=15;
  int top=0;
  private int A[]=new int[length];
  public void push(int num){
    if(top==length){
      System.out.println("Overflow");
      return;
    }
    A[top]=num;
    top++;
  }

  public void pop(){
    if(top==0){
      System.out.println("Underflow");
      return;
    }
    top--;
  }
  
  public void displayStack(){
    int i;
    for(i=0;i<top;i++)
      System.out.print(A[i]+" ");
    System.out.print("\n"); 
  }

  public int getSize(){
    return length;
  }
  public int getTop(){
    return A[top-1];
  }
  public boolean isEmpty(){
    if(top==0)
      return true;
    else
      return false;
  }
  public boolean isFull(){
    if(top==length)
      return true;
    else 
      return false;
  } 
  
  public boolean isSymbol(char c)
    {
       boolean p;
       switch(c)
       { case '/' : p=true;
                    break; 
         case '*' : p=true;
                    break;
         case '+' : p=true;
                    break; 
         case '-' : p=true;
                    break;
         case '^' : p=true;
                    break; 
         default : p=false;
       }
       return p;
    }

   public boolean isNum(char c){
      if(c>='0' && c<='9')
        return true;
      else
        return false; 
   }
}
