//Programmed by Gautham
import java.util.Scanner;
public class BinaryTreeDriver {

	public static void main(String[] args) {
		BinaryTree T = new BinaryTree();
		Scanner sc = new Scanner(System.in);
		int x,y;
		do {
			System.out.println("Enter 1 : for insertion");
			System.out.println("Enter 2 : for deletion");
			System.out.println("Enter 3 : for PreOrder");
			System.out.println("Enter 4 : for InOrder");
			System.out.println("Enter 5 : for PostOrder");
			System.out.println("Enter 6 : to exit");
			x=sc.nextInt();
			switch(x) {
			case 1 : System.out.println("Enterthenumber");
					 y=sc.nextInt();
					 T.insert(y);
					 break;
			case 2 : System.out.println("Enterthenumber");
                     y=sc.nextInt();
                     T.Delete(y);
                     break;
			case 3 : T.PerOrder();
			         break;
			case 4 : T.InOrder();
			         break;
			case 5 : T.PostOrder();         
			         break; 
			}
			if(x==6)
				break;
		}while(true);
		sc.close();
	}
}
