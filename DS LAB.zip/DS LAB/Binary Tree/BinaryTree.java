//Programmed by Gautham
import java.util.*;
public class BinaryTree {
	NODE head=null;
	Queue<NODE> Q = new LinkedList<NODE>();
	NODE BFSNode(NODE e) {
		Q.poll();
		if(e.left==null)
			return e;
		else
			Q.add(e.left);
		if(e.right==null)
			return e;
		else
			Q.add(e.right);
		return BFSNode(Q.peek());
	}
	NODE findIncompleteNode() {
		Q.clear();
		Q.add(head);
		NODE P = BFSNode(Q.peek());
		return P;
	}
	NODE BFSParent(NODE e,NODE P) {
		Q.poll();
		if(e.left==null)
			return P;
		else
			Q.add(e.left);
		P=e;
		if(e.right==null)
			return P;
		else
			Q.add(e.right);
		return BFSParent(Q.peek(),P);
	}
	NODE findLastParent() {
		Q.clear();
		Q.add(head);
		NODE P=head;
		P = BFSParent(Q.peek(),P);
		return P;
	}
	NODE BFSFind(NODE e,int x) {
		Q.poll();
		if(e.value==x)
			return e;
		else
		{
			if(e.left!=null)
				Q.add(e.left);
			if(e.right!=null)
				Q.add(e.right);
		}
		if(!Q.isEmpty()) {
			return BFSFind(Q.peek(),x);
		}
		else {
			return null;
		}
	}
	void insert(int x) {
		NODE y = new NODE(x);
		if(head==null)
			head=y;
		else
		{	
			NODE P = findIncompleteNode();
			if(P.left==null)
				P.left=y;
			else
				P.right=y;
		}
		display();
	}
	NODE find(int x) {
		Q.clear();
		Q.add(head);
		NODE P=null;
		P=BFSFind(Q.peek(),x);
		return P;
	}
	void Delete(int x) {
		NODE P = findLastParent();
		NODE C = find(x);
		if(C==null) {
			System.out.println("No element");	
		}
		else {
			if(P.right!=null) {
				C.value=P.right.value;
				P.right=null;
			}
			else if(P.left!=null) {
				C.value=P.left.value;
				P.left=null;
			}
			else {
				head=null;
			}
			display();
		}
	}
	void doPreOrder(NODE e) {
		if(e==null)
			return;
		System.out.print(e.value+" ");
		doPreOrder(e.left);
		doPreOrder(e.right);
	}
	void PerOrder() {
		doPreOrder(head);
		System.out.println();
	}
	void doPostOrder(NODE e) {
		if(e==null)
			return;
		doPostOrder(e.left);
		doPostOrder(e.right);
		System.out.print(e.value+" ");
	}
	void PostOrder() {
		doPostOrder(head);
		System.out.println();
	}
	void doInOrder(NODE e) {
		if(e==null)
			return;
		doInOrder(e.left);
		System.out.print(e.value+" ");
		doInOrder(e.right);		
	}
	void InOrder() {
		doInOrder(head);
		System.out.println();
	}
	void Print(NODE e) {
		if(e==null)
			return;
		Q.poll();
		System.out.print(e.value + " ");
		if(e.left!=null)
			Q.add(e.left);
		if(e.right!=null)
			Q.add(e.right);
		if(!Q.isEmpty()) {
			Print(Q.peek());
		}
	}
	void display() {
		Q.clear();
		Q.add(head);
		Print(Q.peek());
		System.out.println();
	}
}
