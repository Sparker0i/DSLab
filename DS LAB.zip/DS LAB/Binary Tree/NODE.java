//Programmed by Gautham
public class NODE {
	int value;
	NODE left,right;
	public NODE(int v) {
		value = v;
		left=null;
		right=null;
	}

}
