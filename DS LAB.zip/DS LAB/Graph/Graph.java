public class Graph
{  int[][] g;
   Graph()
   {  g=new int[12][12];
      int i,j;
 
      for(i=0;i<12;i++)
      {  for(j=0;j<12;j++)
           g[i][j]=0;
      }
   }
   
   public void addVertex(int u,int v)
   {  g[u-1][v-1]=1;
      g[v-1][u-1]=1; 
   }

   public void square()
   {   int i,j,k;
       int[][] A=new int[12][12];
       
       for(i=0;i<12;i++)
       {  for(j=0;j<12;j++)
            A[i][j]=0;
       } 

       for(i=0;i<12;i++)
       {  for(j=0;j<12;j++)
          {  for(k=0;k<12;k++)
             {  A[i][j]+=(g[i][k]*g[k][j]);
             }  
          }   
       }

       for(i=0;i<12;i++)
       {  for(j=0;j<12;j++)
          {  System.out.print(A[i][j]+" ");
          }
          System.out.println();    
       }
       System.out.println();
   }

   public void display()
   {  int i,j;
      for(i=0;i<12;i++)
      {  for(j=0;j<12;j++)
         {  System.out.print(g[i][j]+" ");
         }
         System.out.println();
      } 
      System.out.println();
   }

   public void showDegree(int n)
   {  int i,l=0;
      MyQueue q=new MyQueue(12);
      for(i=0;i<12;i++)
      {  if(g[n-1][i]==1)
         {  q.Enqueue((i+1));
            l++;
         }
      }
      System.out.println("Node "+n+": Degree "+ l);
      q.display(); 
   } 
} 
