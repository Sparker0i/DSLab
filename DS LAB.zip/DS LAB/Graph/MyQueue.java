public class MyQueue {
  protected int A[];
  int size,front,rear,length;
  MyQueue(int n)
  {
     size=n;
     A=new int[n];
     length=0;
     front=-1;
     rear=-1;
  }

  public boolean isEmpty()
  {  if(front==-1 && rear==-1)
       return true;
     else
       return false; 
  }

  public boolean isFull()
  {
     if(rear==(size-1))
       return true;
     else
       return false;
  }

  public void Enqueue(int num)
  {  
     if(isFull()==true){
       System.out.println("Queue is Full");
       return;
     }
     else if(front==-1 && rear==-1) {
       front=0;
       rear=0;
       A[rear]=num;
     }
     else {
       rear=rear+1;
       A[rear]=num; 
     }
  }

  public void Dequeue() 
  {  if(isEmpty()==true)
     { System.out.println("Queue is Empty");
       return; 
     }
     else if(front==rear){
       front=-1;
       rear=-1;
     }
     else {
       front++;
     }
  }

  public int peek(){
    if(isEmpty()==true)
    {  System.out.println("Queue is Empty");
       return -1;
    }
    else {
       return A[front];
    } 
  }

  public void display(){
    if(front==-1 && rear==-1)
    {  System.out.println("Empty Queue");
       return;
    }
    else
    {  int i;
       for(i=front;i<=rear;i++)
       { System.out.print(A[i]+" ");
       }
       System.out.println("");
    } 
  }

  public int getSize()
  {   
     if(front==-1 && rear==-1)
       return 0;
     else 
       return (rear-front+1);
  }
}
