public class Driver
{  public static void main(String[] args)
   {  Graph gR=new Graph();
      gR.addVertex(1,2);
      gR.addVertex(1,3);
      gR.addVertex(2,3);
      gR.addVertex(1,4);
      gR.addVertex(4,5);
      gR.addVertex(3,5);
      gR.addVertex(5,6);
      gR.addVertex(9,10);
      gR.addVertex(10,11);
      gR.addVertex(9,12);
      gR.display();
      gR.showDegree(1);
      gR.showDegree(3); 
   } 
}
