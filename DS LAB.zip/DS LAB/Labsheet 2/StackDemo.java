import java.util.Scanner;


public class StackDemo {
  private  int n_size = 10;
  int A[] = new int[n_size];
  int ch[]=new int[n_size];
  int i=0;
  int top = -1;
  public void push(int x) {
// Implement push operation
    if(top>=n_size)
     System.out.println("OverFlow"); 
//Display proper message
    else
      {
        top=top+1;
	A[top]=x;
      }
// Call displayElements()
        displayElements();
}
  public boolean pop() {
// Implement pop operation
    if(top<0)
     {
      System.out.println("UnderFlow\n");	
      return false;
     }
    else
     {
      System.out.println("\n");
      if(ch[top]=='{' && ch[i]=='}')
        top=top-1;
      if(ch[top]=='[' && ch[i]==']')
        top=top-1;
      if(ch[top]=='(' && ch[i]==')')
        top=top-1;
      else
        return false;
      }
//Display proper message
        displayElements();
// Call displayElements()
}
  public void displayElements() {
   System.out.print("\n");
   for (int i = 0; i <= top; i++) {
    System.out.print(A[i]+"\t");
   }
 }
  public int getSize() {return n_size;}
  public int getTop() { return top;
  }
  public boolean isEmpty(){
  if(top<0)
    return true;
  else
    return false;
}
  public boolean isFull(){
   if(top>=n_size)
    return true;
   else
    return false;
 }

 public boolean Brackets() {
    Scanner sc=new Scanner(System.in);
  for(int k=0;k<s.getSize();k++){
    int temp=sc.nextChar();
    if(temp=='{' || temp=='[' || temp=='(') 
     {i++;s.push(temp);}
    else
     if(s.pop()==false)
      return false;
     else
      return true;
    }

 } 

public static void main(String[] args) {
 StackDemo s = new StackDemo();
  Scanner sc=new Scanner(System.in);
 for(int i=0;i<s.getSize();i++){
 s.push(sc.nextInt());
 System.out.print("\n");
 }
//Try push on a full stack
 for(int i=s.getTop();i>=0;i--)
  if(s.pop());
//Try pop on empty stack
 int n= s.getSize();
 System.out.println(n);
//print n
 int m= s.getTop();
 System.out.println(m);
 if(s.Brackets()==true)
  System.out.println("No errors");
 else
 System.out.println("Errors Detected");
 sc.close();
}
}
