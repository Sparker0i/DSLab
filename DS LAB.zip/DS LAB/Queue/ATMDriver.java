import java.util.Random;
public class ATMDriver {

	public static void main(String[] args) {
		ATM A = new ATM(150);
		ATMQueue Q = new ATMQueue(5);
		Random r = new Random();
		int c;
		for(int i=0;i<60;i++) {
			c=r.nextInt(3);
			for(int j=0;j<c;j++) {
				Q.enqueue(i);
		    }
			while(!Q.isEmpty()) {
				A.addCustomer(Q.dequeue());
			}
	    }
		A.display();
    }
}