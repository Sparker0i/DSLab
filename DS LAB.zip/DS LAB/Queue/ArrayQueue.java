import java.util.*;
class arrayQueue
{
	protected int Queue[] ;
	protected int front, rear, size, len;
	/* Constructor */
	public arrayQueue(int n)
	{
		size = n;
		len = 0;
		Queue = new int[size];
		front = -1;
		rear = -1;
	}
	/* Function to check if queue is empty */
	public boolean isEmpty()
	{
		if (front == -1 && rear == -1)
			return true;
		else
			return false;
	}
	/* Function to check if queue is full */
	public boolean isFull()
	{
		if (rear == size - 1)
			return true;
		else
			return false;
	}
	/* Function to get the size of the queue */
	private int getSize()
	{
		return size;		
	}
	/*Function to check the front element of the queue */
	public int peek()
	{
		return Queue[front];
	}
	/*Function to insert an element to the queue */
	public void Enqueue(int i)
	{
		if (isEmpty())
		{
			++front;
			Queue[++rear] = i;
		}
		else
		{
			Queue[++rear] = i;
		}	
	}
	/* Function to remove front element from the queue */
	public int Dequeue()
	{
		if (isEmpty())
			return -1;
		else
		{
			++front;
			return Queue[front - 1];
		}
	}
	/*Function to display the status of the queue */
	public void display()
	{
		for (int i = front; i <= rear; i++)
			System.out.print(Queue[i]+" ");
		System.out.println();
	}
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Array Queue Test\n");
		System.out.println("Enter Size of Integer Queue ");
		int n = scan.nextInt();
		int X;
		/* creating object of class arrayQueue */
		arrayQueue q = new arrayQueue(n);
		/* Perform Queue Operations */
		char ch;
		do
		{
			System.out.println("\nQueue Operations");
			System.out.println("1. Enqueue");
			System.out.println("2. Dequeue");
			System.out.println("3. peek");System.out.println("4. check empty");
			System.out.println("5. check full");
			System.out.println("6. size");
			int choice = scan.nextInt();
			switch (choice)
			{
				case 1 :X= scan.nextInt();
						q.Enqueue(X);
						break;
				case 2 :X = q.Dequeue();
						System.out.println("DEQUEUED ITEM : " + X);
						break;
				case 3 :X = q.peek();
						System.out.println("ITEM AT FRONT : " + X);
						break;
				case 4 :if (q.isEmpty())
							System.out.println("TRUE");
						else
							System.out.println("FALSE");
						break;
				case 5 :if (q.isFull())
							System.out.println("TRUE");
						else
							System.out.println("FALSE");
						break;
				case 6 :X = q.getSize();
						System.out.println("TOTAL SIZE : " + X);
						break;
				default:System.out.println("INVALID CHOICE ENTERED");
			}
			System.out.println("\nDo you want to continue (Type y or n) \n");
			ch = scan.next().charAt(0);
		} 
		while (ch == 'Y'|| ch == 'y');
	}
}
