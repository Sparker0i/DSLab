
public class ATM {
	private int nextAvaTime;
	private int[] inTime;
	private int[] outTime;
	private int timePos;
	public ATM(int s) {
		nextAvaTime = 0;
		timePos = 0;
		inTime = new int[s];
		outTime = new int[s];
	}
	private void updateTime(int time) {
		nextAvaTime=time+1;
	}
	public void addCustomer(int time) {
		if(time>nextAvaTime) {
			updateTime(time);
			addInTime(time);
			addOutTime(nextAvaTime);
		}
		else {
			addInTime(nextAvaTime);
			updateTime(nextAvaTime);
			addOutTime(nextAvaTime);
		}
		timePos++;
	}
	public void addInTime(int time) {
		inTime[timePos]=time;
	}
	public void addOutTime(int time) {
		outTime[timePos]=time;
	}
	public void display() {
		System.out.println("Numbe of customers served = "+timePos);
		System.out.println("Customer number : In Time  :  Out Time");
		for(int i=0;i<timePos;i++) {
			System.out.println("      "+(i+1)+"         :  "+inTime[i]+"       :  "+outTime[i]);
		}
	}
}
