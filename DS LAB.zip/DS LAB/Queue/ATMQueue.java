public class ATMQueue {
	protected int[] Queue ;
	protected int front, rear, size, len;
	public ATMQueue(int n) {
	size = n;
	len = 0;
	Queue = new int[size];
	front = 0;
	rear = 0;
	}
	public boolean isEmpty() {
		if(rear==front)
			return true;
		else
			return false;		
	}
	public boolean isFull() {
		if(front==((rear+1)%size))
			return true;
		else
			return false;
	}
	public int enqueue(int n) {
		if(isFull()) 
			return -1;
		else {
			Queue[rear]=n;
			rear++;
			if(rear>=size);
			rear=rear%size;
			return 1;
	    }
	}	
	public int dequeue() {
		int n;
		if(isEmpty()) {
			return -1;
		}
		else {
			n=Queue[front];
			front++;
			if(front>=size)
				front=front%size;
			return n;
		}
	}
}
