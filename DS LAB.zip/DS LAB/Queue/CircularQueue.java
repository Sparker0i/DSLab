import java.util.Scanner;
class CircularQueue {
	Scanner sc = new Scanner(System.in);
	protected int[] Queue ;
	protected int front, rear, size, len;
	public CircularQueue(int n) {
	size = n;
	len = 0;
	Queue = new int[size];
	front=0;
	rear = 0;
	}
	public boolean isEmpty() {
		if(rear==front)
			return true;
		else
			return false;		
	}
	public boolean isFull() {
		if(front==((rear+1)%size))
			return true;
		else
			return false;
	}
	public int getSize() {
		int s=rear-front;
		if(s<0)
			s+=size;
		return s;
	}
	public int peek() {
		if(isEmpty()) {
			System.out.println("No elements in Queue");
			return -1;
		}
		return Queue[front];
	}
	public void enqueue() {
		int n;
		if(isFull()) 
			System.out.println("Overflow");
		else {
			System.out.println("Enter the element");
			n=sc.nextInt();
			Queue[rear]=n;
			rear++;
			if(rear>=size);
			rear=rear%size;
			display();
	    }
	}	
	public int dequeue() {
		int n;
		if(isEmpty()) {
			System.out.println("Underflow");
			return -1;
		}
		else {
			n=Queue[front];
			front++;
			if(front>=size)
				front=front%size;
			display();
			return n;
		}
	}
	public void display() {
		int i=front;
		while(i!=rear) {
			System.out.print(Queue[i]+" ");
			i++;
			if(i>=size)
				i=i%size;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Circular Queue Test");;
		System.out.println("Enter the size of the queue");
		int n=scan.nextInt();
		CircularQueue Q = new CircularQueue(n);
		int x;
		do {
			System.out.println("\nQueue Operations");
			System.out.println("1. Enqueue");
			System.out.println("2. Dequeue");
			System.out.println("3. peek");
			System.out.println("4. check empty");
			System.out.println("5. check full");
			System.out.println("6. size");
			System.out.println("7. display");
			System.out.println("8. exit");
			x=scan.nextInt();
			switch(x) {
			case 1 : Q.enqueue();break;
			case 2 : Q.dequeue();break;
			case 3 : int y=Q.peek();
					 if(y!=-1)
						 System.out.println(y);
					 break;
			case 4 : if(Q.isEmpty())
						System.out.println("Queue is empty");
					 else
						System.out.println("Queue is not empty");
					 break;
			case 5 : if(Q.isFull())
						System.out.println("Queue is full");
			 		 else
			 			System.out.println("Queue is not full");
			 		 break;		 
			case 6 : System.out.println(Q.getSize());
					 break;
			case 7 : Q.display();		 
		    }
			if(x==8)
				break;	
		}while(true);
		scan.close();
	}
}

