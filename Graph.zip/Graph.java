public class Graph 
{
    private final int vertices;
    private int[][] matrix;
    private int count;

    public Graph(int v) 
    {
        vertices = v;
        count = 0;
    	matrix = new int[vertices + 1][vertices + 1];
    }
    
    public void makeEdge(int to, int from, int edge) 
    {
        matrix[to][from] = edge;
    }
    
    public int getEdge(int to, int from) 
    {
        return matrix[to][from];
    }
    
    public void display() {
    	int v = vertices;
    	System.out.println("The adjacency matrix for the given graph is: ");
        System.out.print("   ");
        for (int i = 1; i <= v; i++)
            if (i <= 9)
            	System.out.print(i + "  ");
            else
            	System.out.print(i + " ");
        System.out.println();
        for (int i = 1; i <= v; i++) 
        {
        	if (i <= 9)
            	System.out.print(i + "  ");
            else
            	System.out.print(i + " ");
            for (int j = 1; j <= v; j++)
                	System.out.print(getEdge(i, j) + "  ");
            System.out.println();
        }
    }
    
    public void degree(int k) {
    	int count = 0;
    	System.out.print("Nodes : {");
    	for (int j = 1; j <= vertices; ++j) {
    		if (matrix[k][j] == 1)
    		{	System.out.print(j + ", ");
    			++count;
    		}
    	}
    	System.out.println("}");
    	System.out.println("No. of nodes : " + count);
    }
    
    public void addVertex(int to , int from) {
        makeEdge(to, from, 1);
        makeEdge(from, to, 1);
        if (matrix[to][from] == 0 && matrix[from][to] == 0)
        	count++;
    }
}
